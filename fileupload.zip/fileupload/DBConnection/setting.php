<?php 

// All constent Database connection Raleted.

define("HOST","localhost:3308");
define("USERNAME","root");
define("PASSWORD","");
define("DBNAME","techpile");






 ?>