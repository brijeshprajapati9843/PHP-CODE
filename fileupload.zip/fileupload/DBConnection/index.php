<form action="controller.php" method="POST">
	Name<input type="text" name="name"><br><br>
	Email<input type="text" name="email"><br><br>
	<input type="submit" name="submit" value="Submit">
</form>