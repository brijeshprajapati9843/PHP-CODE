<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<style>
		.gallery
		{
			height: 200px;
			width: 200px;
			float: left;
			margin-right: 30px;

		}
		.gallery img
		{
			height: 100%;
			width: 100%;
			border-radius: 50%;
		}
		a
		{
			float: right;
			background-color: orangered;
			padding: 10px 20px;
			color: #fff;
			text-decoration: none;
			border-radius: 5px;
		}	
	</style>
</head>
<body>
	
</body>
</html>