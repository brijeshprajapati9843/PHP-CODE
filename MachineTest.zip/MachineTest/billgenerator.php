
 <form action="generate.php" method="post">
 Total Bill : <input type="text" name="bill"><br><br>
 <input type="submit" value="Submit">
 </form>