<?php 
include_once __DIR__.'/db.php';
if (isset($_POST['submit']) && !empty('city')) {
	$city = $_POST['city'];
	$sql = "INSERT INTO city(name)VALUES('$city')";
	if (mysqli_query($conn,$sql)) {
		header('location:city.php');
	}else{
		echo "Cannot Inserted.";
	}
}
$sql1 = "SELECT * FROM city";

 ?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="UTF-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
 	<title>Document</title>
 </head>
 <body>
 	<form action="" method="post">
 		City Name :<br><input type="text" name="city"><br><br>
 		<input type="submit" value="Submit" name="submit"><br><br>

 		Select City :
 		<select>
 			<option value="">Select City</option>

 			<option value="<?php  ?>"></option>
 		</select>
 	</form>
 </body>
 </html>