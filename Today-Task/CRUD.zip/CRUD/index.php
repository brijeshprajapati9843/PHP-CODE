<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Register</title>
</head>
<body>
	<h2>Register Here</h2>
	<hr>
	<form action="registerHandler.php" method="post">
		Name : <input type="text" name="name"/><br><br>
		Email : <input type="text" name="email"/><br><br>
		Mobile : <input type="number" name="mobile"/><br><br>
		<input type="submit" value="Register">
	</form>
</body>
</html>