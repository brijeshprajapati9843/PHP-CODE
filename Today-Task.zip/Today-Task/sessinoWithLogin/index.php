<form action="userLogin.php" method="post">
	Username : <input type="text" name="username"><br><br>
	Password : <input type="password" name="password"><br><br>
	<input type="submit" value="Login">
</form>