<?php

//This is Setting file

################ All Constants ##########################
define('HOST','localhost:3308');
define('USER','root');
define('PASSWORD','');
define('DBNAME','app2022');
define('BASE_URL','http://localhost:8000/');
// define('BASE_URL','http://localhost:786/APP2021/CRUD/web/');

################ All Constants ##########################

return [
	
	'db:config'=>[
		
		'host'=>'localhost:3308',
		'user'=>'root',
		'password'=>'',
		'dbname'=>'app2022',
	],
	'db:debug' => true,

];