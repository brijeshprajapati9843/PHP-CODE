<?php

//This is Setting file

################ All Constants ##########################
define('HOST','localhost:3308');
define('USER','root');
define('PASSWORD','');
define('DBNAME','app2021');
define('DB_CHECK',false);

################ All Constants ##########################

return [
	
	'db:config'=>[
		
		'host'=>'sql5.freesqldatabase.com',
		'user'=>'sql5468918',
		'password'=>'957kmWRLmS',
		'dbname'=>'sql5468918',
	]

];
