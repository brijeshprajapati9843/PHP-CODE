<?php
include __DIR__.'/header.php';
include __DIR__.'/menubar.php';
?>

<h1>This is heading</h1>
<h1>This is heading</h1>

<?php
include __DIR__.'/footer.php';
?>
