<div class="menubar">
	<div class="logo">
		<h2>LEARNING <span style="color: red;"> POINT</span></h2>
	</div>
	<div class="navbar">
	
	<ul>
		<li><a href="">Home</a></li>
		<li><a href="">About Us</a></li>
		<li><a href="">Services</a></li>
		<li><a href="">Contact Us</a></li>
		<li><a href="">Login</a></li>
		<li><a href="">Register</a></li>
	</ul>
	</div>
</div>