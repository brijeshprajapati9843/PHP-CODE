<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<style>
		.container img
		{
			height: 150px;
			margin-right: 20px;
		}
	</style>
</head>
<body onload="demo()">
	<script>
		function demo(){
			var num = Math.ceil(Math.random()*10);
			var img = document.getElementById(num);
			// document.write(img);
			var val =  v.src;
			var img = val;



		}
	</script>
</body>
</html>