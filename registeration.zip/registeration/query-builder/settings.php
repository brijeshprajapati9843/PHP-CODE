<?php

//This is Setting file

################ All Constants ##########################
define('HOST','localhost:3308');
define('USER','root');
define('PASSWORD','');
define('DBNAME','student');
define('BASE_URL','http://localhost:7000/');

################ All Constants ##########################

return [
	
	'db:config'=>[
		
		'host'=>'localhost:3308',
		'user'=>'root',
		'password'=>'',
		'dbname'=>'student',
	],
	
	'connection:debug' => false,

];
